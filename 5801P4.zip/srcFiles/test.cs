// {START
// This is a test file for testing PPALMS Program
using System;
namespace test
{
  class Test
  {
    static void Main(string[] args)
    {
      // START}
      // {*
      int x = 0;
      int y = 0;
      // *}
      int z = x + y;
      Console.WriteLine(z);
      // {END
    }
  }
}
// END}