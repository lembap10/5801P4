package srcFiles;
// {START
// This is a test file for testing PPALMS Program 
public class Test{
    public static void main(String[] args){
    // START}
    // {*
    int x = 0;
    int y = 0;
    // *}
    int z = x + y;
    
    System.out.println(z);
    // {END
    } 
}
 // END}
