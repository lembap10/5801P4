# {START
# This is a test file for testing PPALMS Program

def main():
    # START}
    # {*
    x = 0
    y = 0
    # *}
    z = x + y
    print(z)
    # {END
    return 0
# END}