(* {START *)
(* This is a test file for testing PPALMS Program *)
let main x y =
  (* START} *)

  (* {* *)
  match x 
  (* *} *)

  (* {END *)
  with 1 -> x + y
  | 2 -> x - y
(* END} *)


