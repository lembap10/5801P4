// This is a test file for testing PPALMS Program
#include <iostream>
using namespace std;

int main(){
    // {*
    int x = 0;
    int y = 0;
    // *}
    int z = x + y;
    cout << z;
    // {END
    return z;
}
// END}