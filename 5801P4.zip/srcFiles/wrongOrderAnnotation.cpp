// END}
// This is a test file for testing PPALMS Program
#include <iostream>
using namespace std;

int main()
{
    // {END
    // *}
    int x = 0;
    int y = 0;
    // {*
    int z = x + y;
    cout << z;
    // START}
    return z;
}
// {START
