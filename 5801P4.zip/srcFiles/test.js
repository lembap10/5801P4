// {START
// This is a test file for testing PPALMS Program
class Test {}
Test.main = (args) => {
  // START}
  // {*
  let x = 0;
  let y = 0;
  // *}
  let z = x + y;
  console.log(z);
  // {END
  return z;
};
// END}