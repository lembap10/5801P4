#ifndef TESTER_H
#define TESTER_H

#include "../include/DefaultCodeParser.h"

void test_equivalence(void* actual, void* expected, string type, string testName);

#endif