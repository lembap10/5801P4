#ifndef COMBINEDTESTS_H
#define COMBINEDTESTS_H
#include "tester.h"

void NLTests();

void YXTests();

void YYTests();

#endif
