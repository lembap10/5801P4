#include "CombinedTests.h"

using namespace std;
int main(){
    cout << "BEGIN COMBINED TESTS" << endl;
    NLTests();
    YXTests();
    YYTests();
}